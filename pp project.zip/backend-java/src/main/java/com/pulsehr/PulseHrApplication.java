package com.pulsehr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PulseHrApplication {
  public static void main(String[] args) {
    SpringApplication.run(PulseHrApplication.class, args);
  }
}
